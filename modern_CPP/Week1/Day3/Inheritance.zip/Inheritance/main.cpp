#include<iostream>
#include"Vehicle.h"

int main()
{

    return 0;
}