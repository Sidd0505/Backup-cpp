#ifndef PAYMENTMODE_H
#define PAYMENTMODE_H

enum class PaymentMode{
    CARD,
    ONLINE_WALLET,
    UPI
};

#endif // PAYMENTMODE_H
