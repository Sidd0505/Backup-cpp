#include<iostream>
#include<thread>

int main()
{
    int n1 =10;
    std::thread t1([](int arg)(std::cout<<arg;},))
}