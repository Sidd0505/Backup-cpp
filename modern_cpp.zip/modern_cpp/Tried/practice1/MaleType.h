#ifndef MALETYPE_H
#define MALETYPE_H

enum class Male_type{
    BOY,MEN
};

#endif // MALETYPE_H
