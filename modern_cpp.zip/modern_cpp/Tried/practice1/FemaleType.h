#ifndef FEMALETYPE_H
#define FEMALETYPE_H

enum class Female_type{
    GIRL,WOMEN
};

#endif // FEMALETYPE_H
