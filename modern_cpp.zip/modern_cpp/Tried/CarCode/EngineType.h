#ifndef ENGINETYPE_H
#define ENGINETYPE_H

enum class EngineType{
    PETROL, DISEL, EV, HYBRID
};

#endif // ENGINETYPE_H
