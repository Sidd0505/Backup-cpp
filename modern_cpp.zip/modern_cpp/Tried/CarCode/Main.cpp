#include"Functionalities.h"


int main()
{
    CarContainer (cardata);
    EngineContainer (enginedata);

    CreateClassObjects(cardata, enginedata);
    Display(cardata);
    
}