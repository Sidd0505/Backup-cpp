#ifndef _DEVICE_TYPE_H
#define _DEVICE_TYPE_H

#include<iostream>

enum class _device_type{
    INFORTAINMENT,
    ACCESORY,
    SAFETY
};

#endif // _DEVICE_TYPE_H
