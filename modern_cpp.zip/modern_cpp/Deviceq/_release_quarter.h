#ifndef _RELEASE_QUARTER_H
#define _RELEASE_QUARTER_H

#include<iostream>

enum class _release_quarter
{
    Q1,
    Q2,
    Q3,
    Q4
};
#endif // _RELEASE_QUARTER_H
