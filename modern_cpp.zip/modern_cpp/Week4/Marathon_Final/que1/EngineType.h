#ifndef ENGINETYPE_H
#define ENGINETYPE_H

#include <iostream>

enum class EngineType{
    PETROL,
    DIESEL,
    HYBRID
};

#endif // ENGINETYPE_H
