#ifndef SKILLSET_H
#define SKILLSET_H

#include <iostream>

enum class SkillSet {
    CODING,
    UNIT_TESTING,
    CODE_REVIEW,
    INTEGRATION_TESTING
};

#endif // SKILLSET_H
