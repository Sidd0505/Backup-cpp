#ifndef DEVICE_TYPE_H
#define DEVICE_TYPE_H

enum class Device_type{
    INFOTAINMENT,ACCESSORY,SAFETY
};

#endif // DEVICE_TYPE_H
