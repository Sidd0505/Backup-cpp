#ifndef GRADES_H
#define GRADES_H

enum class Grades{
    A,
    B,
    C
};

#endif // GRADES_H
