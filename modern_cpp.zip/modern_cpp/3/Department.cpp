#include "Department.h"

Department::Department(std::string id, int size)
:_id(id),_size(size)
{
}

