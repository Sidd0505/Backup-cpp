#ifndef ENGINETYPE_H
#define ENGINETYPE_H

enum class EngineType{

    PETROL,
    DISEL,
    HYBRID
};

#endif // ENGINETYPE_H
