#ifndef ENGINETYPE_H
#define ENGINETYPE_H

enum class EngineType{
    Petrol,diesel,hybrid
};

#endif // ENGINETYPE_H
