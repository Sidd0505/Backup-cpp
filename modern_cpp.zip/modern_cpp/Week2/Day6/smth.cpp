/*
    sendNotification(){

    }
    BrakePadObject()
    {
            private:
                _type;
                _data_of_installation;
                _current_level;
                _timestamp;

                if you want to make a object permanantly then use the lvalue reference ,
                if you want to temporary object use rvalue reference;
    }

*/