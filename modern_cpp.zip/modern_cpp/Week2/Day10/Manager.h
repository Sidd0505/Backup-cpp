class Manager
{
private:
    /* data */
public:
    Manager(/* args */);
    ~Manager();
};

Manager::Manager(/* args */)
{
}

Manager::~Manager()
{
}
