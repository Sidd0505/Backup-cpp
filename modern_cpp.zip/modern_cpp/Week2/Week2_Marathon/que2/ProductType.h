#ifndef PRODUCTTYPE_H
#define PRODUCTTYPE_H

#include <iostream>

enum class Product_Type{
    FOOD,
    PERFUME,
    APPLIANCE
};

#endif // PRODUCTTYPE_H
