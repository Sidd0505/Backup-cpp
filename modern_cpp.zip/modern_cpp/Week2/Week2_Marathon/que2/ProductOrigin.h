#ifndef PRODUCTORIGIN_H
#define PRODUCTORIGIN_H

#include <iostream> 

enum class Product_Origin {
    DOMESTIC,
    IMPORTED
};

#endif // PRODUCTORIGIN_H
