#ifndef PRODUCTTYPE_H
#define PRODUCTTYPE_H

enum class ProductType{
    FOOD,
    PERFUME,
    APPLIANCES
};

#endif // PRODUCTTYPE_H
