#ifndef _CUSTOMER_TYPE_H
#define _CUSTOMER_TYPE_H

#include<iostream>

enum class CustomerType{
    NORMAL,ELITE
};

#endif // _CUSTOMER_TYPE_H
