#ifndef DEBITCARDTYPE_H
#define DEBITCARDTYPE_H



enum class  DebitCardType{
    REGULAR,
    GOLD,
    PLATINUM
};

#endif // DEBITCARDTYPE_H
