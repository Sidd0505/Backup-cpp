#ifndef VEHICLETYPE_H
#define VEHICLETYPE_H

enum class VehicleType{
    SEDAN,HATCHBACK,COMMUTE,SPORTS,
    SUV
};

#endif // VEHICLETYPE_H
