
#ifndef BIKETYPE_H
#define BIKETYPE_H

enum class VehicleType{
    SPORTS,
    COMMUTE
};

#endif // BIKETYPE_H
