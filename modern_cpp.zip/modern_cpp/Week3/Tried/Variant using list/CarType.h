#ifndef CARTYPE_H
#define CARTYPE_H

enum class VehicleType{
    SEDAN, SUV, HATCHBACK
};



#endif // CARTYPE_H
