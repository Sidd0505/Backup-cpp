#ifndef HOTELTYPE_H
#define HOTELTYPE_H

enum class HotelType{
    LUXURIOUS,
    THREE_STORY,
    TWO_STORY,
    SINGLE_STORY
};

#endif // HOTELTYPE_H
