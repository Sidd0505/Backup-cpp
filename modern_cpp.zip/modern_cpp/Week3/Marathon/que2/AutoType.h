#ifndef AUTOTYPE_H
#define AUTOTYPE_H

#include <iostream>

enum class AutoType {
    REGULAR,
    TRANSPORT
};

#endif // AUTOTYPE_H
