#include <array>
#include <thread>
#include <iostream>
#include <functional>
#include <mutex>
#include <condition_variable>
#include <vector>



void GlobalNumbersSum();
void OddNumbersDisplayFunction(std::vector<int> v);
void SumOfNNumbers(int N);