#include"Functionalities.h"
#include<iostream>

int main()
{
    Container(data);

    CreateObjects(data);

    CalculateTaxPayable(data);
}