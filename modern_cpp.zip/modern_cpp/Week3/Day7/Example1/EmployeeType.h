#ifndef EMPLOYEETYPE_H
#define EMPLOYEETYPE_H

enum class EmployeeType{
        REGULAR,
        OVERSEAS
};

#endif // EMPLOYEETYPE_H
