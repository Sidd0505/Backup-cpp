#ifndef BUSINESSTYPE_H
#define BUSINESSTYPE_H

enum class BusinessType{
        BRANDED,
        LOCAL
};

#endif // BUSINESSTYPE_H
