#ifndef ORDER_TYPE_H
#define ORDER_TYPE_H

enum class Order_type{
    PAID,COD,PROMOTION
};

#endif // ORDER_TYPE_H
