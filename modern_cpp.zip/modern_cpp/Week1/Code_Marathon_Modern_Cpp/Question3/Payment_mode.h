#ifndef PAYMENT_MODE_H
#define PAYMENT_MODE_H

#include"OnlinePaymentCabBooking.h"

enum class _payment_mode{
    CARD,
    ONLINE_WALLET,
    UPI
};

#endif // PAYMENT_MODE_H
