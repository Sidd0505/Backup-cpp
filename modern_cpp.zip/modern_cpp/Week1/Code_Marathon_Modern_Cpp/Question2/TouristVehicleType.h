#ifndef TOURISTVEHICLETYPE_H
#define TOURISTVEHICLETYPE_H

#include<iostream>

enum class TouristVehicleType{
    CAB,
    BUS,
    BIKE
};

#endif // TOURISTVEHICLETYPE_H
