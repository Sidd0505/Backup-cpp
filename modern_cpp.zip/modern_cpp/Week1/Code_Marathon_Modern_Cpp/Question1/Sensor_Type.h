#ifndef SENSOR_TYPE_H
#define SENSOR_TYPE_H

#include<iostream>

enum class SensorType{
    TYRE_PRESSURE,
    TEMPERATURE,
    CABIN_PRESSURE
};

#endif // SENSOR_TYPE_H
