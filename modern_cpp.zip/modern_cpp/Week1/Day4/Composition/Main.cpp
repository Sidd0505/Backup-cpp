#include"Functionalities.h"

int main()
{
    Container data;  //empty container vaector

    CreateObjects(data);
}