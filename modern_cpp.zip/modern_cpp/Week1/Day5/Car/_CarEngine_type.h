#include<iostream>

enum class EngineType{
    ICT,
    HYBRID
};