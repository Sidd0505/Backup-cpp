#include<iostream>

enum class CarType{
    SEDAN,
    SUV,
    SPORTS,
    HATCHBACK
};