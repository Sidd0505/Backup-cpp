#ifndef DEBITCARDTYPE_H
#define DEBITCARDTYPE_H

#include<iostream>

enum class DebitCardType
{
    DOMESTIC,
    INTERNANTIONAL
};

#endif // DEBITCARDTYPE_H
