//enum ke liye header file chahiye

#ifndef VEHICLETYPE_H
#define VEHICLETYPE_H

enum class VehicleType
{
    PERSONAL,
    TRANSPORT,
    SECURITY
};


#endif // VEHICLETYPE_H
