#ifndef VEHICLETYPE_H
#define VEHICLETYPE_H

#include<iostream>

enum class VehicleType{
    PERSONAL,
    SECURITY,
    BUINESS
};

#endif // VEHICLETYPE_H
